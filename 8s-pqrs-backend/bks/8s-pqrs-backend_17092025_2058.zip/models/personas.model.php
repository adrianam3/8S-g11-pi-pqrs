<?php
// TODO: Clase de Personas (tabla `personas`)
require_once('../config/config.php');

class Personas
{
    // === LISTAR (con filtros opcionales) ===
    public function todos($limit = 100, $offset = 0, $soloActivos = null, $q = null)
    {
        $conObj = new ClaseConectar();
        $con    = $conObj->ProcedimientoParaConectar();

        $conds = [];
        $types = '';
        $vals  = [];

        if ($soloActivos === 1 || $soloActivos === true || $soloActivos === '1') {
            $conds[] = 'p.estado = 1';
        } elseif ($soloActivos === 0 || $soloActivos === false || $soloActivos === '0') {
            $conds[] = 'p.estado = 0';
        }

        if (!is_null($q) && $q !== '') {
            $conds[] = '(p.cedula LIKE ? OR p.nombres LIKE ? OR p.apellidos LIKE ? OR p.email LIKE ? OR p.celular LIKE ? OR p.telefono LIKE ?)';
            $types  .= 'ssssss';
            $like    = '%' . $q . '%';
            array_push($vals, $like, $like, $like, $like, $like, $like);
        }

        $where  = count($conds) ? ('WHERE ' . implode(' AND ', $conds)) : '';
        $limit  = max(0, (int)$limit);
        $offset = max(0, (int)$offset);

        $sql = "SELECT p.idPersona, p.cedula, p.nombres, p.apellidos, p.direccion, p.telefono, p.extension, p.celular, p.email, p.estado, p.fechaCreacion, p.fechaActualizacion
                  FROM personas p
                  $where
              ORDER BY p.fechaActualizacion DESC, p.idPersona DESC
                 LIMIT $limit OFFSET $offset";

        $stmt = $con->prepare($sql);
        if (!$stmt) { error_log('Error al preparar: ' . $con->error); $con->close(); return false; }

        if ($types !== '') { $stmt->bind_param($types, ...$vals); }
        if (!$stmt->execute()) { error_log('Error al ejecutar: ' . $stmt->error); $stmt->close(); $con->close(); return false; }

        $res  = $stmt->get_result();
        $rows = [];
        while ($row = $res->fetch_assoc()) { $rows[] = $row; }
        $stmt->close();
        $con->close();
        return $rows;
    }

    // === OBTENER UNO ===
    public function uno($idPersona)
    {
        $conObj = new ClaseConectar();
        $con    = $conObj->ProcedimientoParaConectar();

        $sql  = 'SELECT * FROM personas WHERE idPersona = ?';
        $stmt = $con->prepare($sql);
        if (!$stmt) { $err = $con->error; $con->close(); return $err; }
        $stmt->bind_param('i', $idPersona);
        if (!$stmt->execute()) { $err = $stmt->error; $stmt->close(); $con->close(); return $err; }

        $res = $stmt->get_result();
        $row = $res->fetch_assoc();
        $stmt->close();
        $con->close();
        return $row ?: null;
    }

    // === INSERTAR ===
    public function insertar($cedula, $nombres, $apellidos, $direccion = null, $telefono = null, $extension = null, $celular, $email, $estado = 1)
    {
        try {
            $conObj = new ClaseConectar();
            $con    = $conObj->ProcedimientoParaConectar();

            $sql  = 'INSERT INTO personas (cedula, nombres, apellidos, direccion, telefono, extension, celular, email, estado) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)';
            $stmt = $con->prepare($sql);
            if (!$stmt) { http_response_code(500); return 'Error al preparar la consulta: ' . $con->error; }

            $estado = (int)$estado;
            $stmt->bind_param('ssssssssi', $cedula, $nombres, $apellidos, $direccion, $telefono, $extension, $celular, $email, $estado);

            if ($stmt->execute()) {
                $insertId = $stmt->insert_id;
                $stmt->close();
                $con->close();
                return $insertId;
            } else {
                $error = $stmt->error;
                $stmt->close();
                $con->close();
                return $error; // p.ej. Duplicate entry si hay índices únicos
            }
        } catch (Exception $e) {
            http_response_code(500);
            return $e->getMessage();
        }
    }

    // === ACTUALIZAR ===
    public function actualizar($idPersona, $cedula, $nombres, $apellidos, $direccion = null, $telefono = null, $extension = null, $celular, $email, $estado = 1)
    {
        try {
            $conObj = new ClaseConectar();
            $con    = $conObj->ProcedimientoParaConectar();

            $sql  = 'UPDATE personas SET cedula = ?, nombres = ?, apellidos = ?, direccion = ?, telefono = ?, extension = ?, celular = ?, email = ?, estado = ? WHERE idPersona = ?';
            $stmt = $con->prepare($sql);
            if (!$stmt) { http_response_code(500); return 'Error al preparar la consulta: ' . $con->error; }

            $estado = (int)$estado; $idPersona = (int)$idPersona;
            $stmt->bind_param('ssssssssii', $cedula, $nombres, $apellidos, $direccion, $telefono, $extension, $celular, $email, $estado, $idPersona);

            if ($stmt->execute()) {
                $affected = $stmt->affected_rows; // filas afectadas
                $stmt->close();
                $con->close();
                return $affected;
            } else {
                $error = $stmt->error;
                $stmt->close();
                $con->close();
                return $error;
            }
        } catch (Exception $e) {
            http_response_code(500);
            return $e->getMessage();
        }
    }

    // === ELIMINAR ===
    public function eliminar($idPersona)
    {
        try {
            $conObj = new ClaseConectar();
            $con    = $conObj->ProcedimientoParaConectar();

            $sql  = 'DELETE FROM personas WHERE idPersona = ?';
            $stmt = $con->prepare($sql);
            if (!$stmt) { http_response_code(500); return 'Error al preparar la consulta: ' . $con->error; }

            $stmt->bind_param('i', $idPersona);
            if ($stmt->execute()) {
                $ok = $stmt->affected_rows > 0 ? 1 : 0; // 1 = eliminado, 0 = no existía
                $stmt->close();
                $con->close();
                return $ok;
            } else {
                $errno = $stmt->errno; $err = $stmt->error;
                $stmt->close(); $con->close();
                if ($errno == 1451) { // restricción FK (p.ej. usuarios)
                    return 'La persona tiene dependencias (usuarios u otros registros).';
                }
                return $err;
            }
        } catch (Exception $e) {
            http_response_code(500);
            return $e->getMessage();
        }
    }

    // === Activar / Desactivar ===
    public function activar($idPersona)    { return $this->cambiarEstado($idPersona, 1); }
    public function desactivar($idPersona) { return $this->cambiarEstado($idPersona, 0); }

    private function cambiarEstado($idPersona, $estado)
    {
        try {
            $conObj = new ClaseConectar();
            $con    = $conObj->ProcedimientoParaConectar();

            $sql  = 'UPDATE personas SET estado = ? WHERE idPersona = ?';
            $stmt = $con->prepare($sql);
            if (!$stmt) { http_response_code(500); return 'Error al preparar la consulta: ' . $con->error; }

            $estado = (int)$estado; $idPersona = (int)$idPersona;
            $stmt->bind_param('ii', $estado, $idPersona);

            if ($stmt->execute()) {
                $af = $stmt->affected_rows;
                $stmt->close(); $con->close();
                return $af;
            } else {
                $err = $stmt->error; $stmt->close(); $con->close();
                return $err;
            }
        } catch (Exception $e) {
            http_response_code(500);
            return $e->getMessage();
        }
    }

    // === Contar (para paginación) ===
    public function contar($soloActivos = null, $q = null)
    {
        $conObj = new ClaseConectar();
        $con    = $conObj->ProcedimientoParaConectar();

        $conds = [];
        $types = '';
        $vals  = [];

        if ($soloActivos === 1 || $soloActivos === true || $soloActivos === '1') {
            $conds[] = 'estado = 1';
        } elseif ($soloActivos === 0 || $soloActivos === false || $soloActivos === '0') {
            $conds[] = 'estado = 0';
        }

        if (!is_null($q) && $q !== '') {
            $conds[] = '(cedula LIKE ? OR nombres LIKE ? OR apellidos LIKE ? OR email LIKE ? OR celular LIKE ? OR telefono LIKE ?)';
            $types  .= 'ssssss';
            $like    = '%' . $q . '%';
            array_push($vals, $like, $like, $like, $like, $like, $like);
        }

        $where = count($conds) ? ('WHERE ' . implode(' AND ', $conds)) : '';
        $sql   = "SELECT COUNT(*) AS total FROM personas $where";

        $stmt = $con->prepare($sql);
        if (!$stmt) { $err = $con->error; $con->close(); return $err; }
        if ($types !== '') { $stmt->bind_param($types, ...$vals); }
        if (!$stmt->execute()) { $err = $stmt->error; $stmt->close(); $con->close(); return $err; }

        $res = $stmt->get_result();
        $row = $res->fetch_assoc();
        $stmt->close();
        $con->close();
        return isset($row['total']) ? (int)$row['total'] : 0;
    }

    // === Dependencias (usuarios) ===
    public function dependencias($idPersona)
    {
        $conObj = new ClaseConectar();
        $con    = $conObj->ProcedimientoParaConectar();
        $out = [ 'usuarios' => 0 ];

        $queries = [ 'usuarios' => 'SELECT COUNT(*) c FROM usuarios WHERE idPersona = ?' ];

        foreach ($queries as $key => $sql) {
            $stmt = $con->prepare($sql);
            if (!$stmt) { $out[$key] = -1; continue; }
            $stmt->bind_param('i', $idPersona);
            if ($stmt->execute()) {
                $res = $stmt->get_result();
                $row = $res->fetch_assoc();
                $out[$key] = isset($row['c']) ? (int)$row['c'] : 0;
            } else {
                $out[$key] = -1;
            }
            $stmt->close();
        }

        $con->close();
        return $out;
    }
}
