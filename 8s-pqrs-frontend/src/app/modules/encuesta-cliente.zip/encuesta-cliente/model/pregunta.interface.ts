export interface IPregunta {
  idEncuesta: number;

}
