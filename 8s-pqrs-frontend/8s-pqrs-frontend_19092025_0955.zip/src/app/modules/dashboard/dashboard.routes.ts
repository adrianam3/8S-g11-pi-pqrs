import { Routes } from '@angular/router';

export const dashboardRoutes: Routes = [
    {
        path: '',
        children: [
            {
                path: '',
                pathMatch: 'full',
                loadComponent: () =>
                    import('./project/dashboard/dashboard').then((m) => m.Dashboard),
            },
        ]
    }
];
