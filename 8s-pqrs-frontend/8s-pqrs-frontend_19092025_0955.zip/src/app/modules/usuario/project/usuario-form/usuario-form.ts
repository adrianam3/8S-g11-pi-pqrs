import { Component } from '@angular/core';

@Component({
  selector: 'app-usuario-form',
  imports: [],
  templateUrl: './usuario-form.html',
  styleUrl: './usuario-form.scss'
})
export class UsuarioForm {

}
