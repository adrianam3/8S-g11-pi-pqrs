// import { Injectable } from '@angular/core';
// import { Observable } from 'rxjs';
// import { ApiService } from './api-service';

// export interface AtencionRow {
//   idClienteErp?: string | null;
//   cedula: string;
//   nombres: string;
//   apellidos: string;
//   email?: string | null;
//   telefono?: string | null;
//   celular?: string | null;
//   idAgencia?: number | null;
//   fechaAtencion: string;            // YYYY-MM-DD
//   numeroDocumento?: string | null;
//   tipoDocumento?: string | null;
//   numeroFactura?: string | null;
//   idCanal?: number | null;
//   detalle?: string | null;
//   cedulaAsesor?: string | null;
// }

// @Injectable({ providedIn: 'root' })
// export class AtencionesService {
//   private base = `/controllers/atenciones.controller.php`;

//   constructor(private api: ApiService) {}

//   // Usa 'todos' (tu controlador ya lo implementa)
//   list(limit=100, offset=0): Observable<any[]> {
//     return this.api.get(`${this.base}?op=todos`, { limit, offset });
//   }

//   // Usa 'upsert' (tu controlador lo acepta y devuelve {success: boolean, ...})
//   upsert(row: AtencionRow): Observable<any> {
//     return this.api.post(`${this.base}?op=upsert`, row);
//   }
// }

// v2
// src/app/modules/Services/atenciones-service.ts
// import { Injectable } from '@angular/core';
// import { Observable } from 'rxjs';
// import { ApiService } from './api-service';

// @Injectable({ providedIn: 'root' })
// export class AtencionesService {
//   constructor(private api: ApiService) {}

//   listAll(params: any = {}): Observable<any[]> {
//     return this.api.get('controllers/atenciones.controller.php?op=todos', params) as any;
//   }

//   upsert(payload: any): Observable<any> {
//     return this.api.post('controllers/atenciones.controller.php?op=upsert', payload) as any;
//   }
// }


//v3
// import { Injectable } from '@angular/core';
// import { HttpClient, HttpParams } from '@angular/common/http';
// import { Observable } from 'rxjs';

// @Injectable({ providedIn: 'root' })
// export class AtencionesService {
//   private base = 'controllers/atenciones.controller.php?op=';

//   constructor(private http: HttpClient) {}

//   listAll(params: { limit?: number; offset?: number } = {}): Observable<any[]> {
//     let p = new HttpParams();
//     Object.entries(params).forEach(([k,v]) => { if (v != null) p = p.set(k, String(v)); });
//     return this.http.get<any[]>(`${this.base}todos`, { params: p });
//   }

//   upsert(payload: any): Observable<any> {
//     // el controlador soporta JSON en el cuerpo (usa read_json_body())
//     return this.http.post(`${this.base}upsert`, payload);
//     // si prefieres el alias:
//     // return this.http.post(`${this.base}upsert_cliente_y_atencion`, payload);
//   }

//   importarExcel(file: File): Observable<any> {
//     const fd = new FormData();
//     fd.append('file', file);
//     return this.http.post(`${this.base}importar_excel`, fd);
//   }
// }


// src/app/modules/Services/atenciones-service.ts
import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({ providedIn: 'root' })
export class AtencionesService {
  private base = '/controllers/atenciones.controller.php?op=';

  constructor(private http: HttpClient) {}

  listAll(params: any = {}): Observable<any[]> {
    return this.http.get<any[]>(`${this.base}todos`, { params });
  }

  upsert(body: any): Observable<any> {
    // El controlador lee JSON a través de read_json_body()
    return this.http.post<any>(`${this.base}upsert`, body);
  }

  importarExcel(file: File): Observable<any> {
    const fd = new FormData();
    fd.append('file', file);
    return this.http.post(`${this.base}importar_excel`, fd);
  }
}
