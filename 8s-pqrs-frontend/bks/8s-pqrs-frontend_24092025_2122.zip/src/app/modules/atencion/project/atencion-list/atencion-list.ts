import { CommonModule } from '@angular/common';
import { Component, OnInit } from '@angular/core';
import { RouterModule } from '@angular/router';

import { MessageService } from 'primeng/api';
import { ButtonModule } from 'primeng/button';
import { ConfirmDialogModule } from 'primeng/confirmdialog';
import { IconFieldModule } from 'primeng/iconfield';
import { InputIconModule } from 'primeng/inputicon';
import { InputTextModule } from 'primeng/inputtext';
import { TableModule } from 'primeng/table';
import { ToastModule } from 'primeng/toast';
import { ProgressBarModule } from 'primeng/progressbar';
import { TooltipModule } from 'primeng/tooltip';

import * as XLSX from 'xlsx';
import { firstValueFrom } from 'rxjs';
import { AtencionesService } from '@/modules/Services/atenciones-service';

type AtencionRow = {
  idClienteErp?: string | null;
  cedula: string;
  nombres: string;
  apellidos: string;
  email?: string | null;
  telefono?: string | null;
  celular?: string | null;
  idAgencia?: number | null;
  fechaAtencion: string;
  numeroDocumento?: string | null;
  tipoDocumento?: string | null;
  numeroFactura?: string | null;
  idCanal?: number | null;
  detalle?: string | null;
  cedulaAsesor?: string | null;
};

@Component({
  selector: 'app-atencion-list',
  standalone: true,
  imports: [
    CommonModule,
    RouterModule,
    TableModule,
    ButtonModule,
    ToastModule,
    ConfirmDialogModule,
    InputTextModule,
    IconFieldModule,
    InputIconModule,
    ProgressBarModule,
    TooltipModule
  ],
  templateUrl: './atencion-list.html',
  styleUrl: './atencion-list.scss',
  providers: [MessageService]
})
export class AtencionList implements OnInit {
  atencionesAll: any[] = [];
  loading = true;

  importing = false;
  progress = 0;
  okCount = 0;
  errCount = 0;

  constructor(
    private atencionesService: AtencionesService,
    private messageService: MessageService
  ) {}

  ngOnInit(): void { this.cargarAtenciones(); }

  cargarAtenciones(): void {
    this.loading = true;
    this.atencionesService.listAll().subscribe({
      next: (data: any[]) => { this.atencionesAll = Array.isArray(data) ? data : []; this.loading = false; },
      error: () => {
        this.messageService.add({ severity: 'error', summary: 'Error', detail: 'No se pudo cargar las atenciones' });
        this.loading = false;
      }
    });
  }

  onGlobalFilter(table: any, event: Event) {
    const input = (event.target as HTMLInputElement).value;
    table.filterGlobal(input, 'contains');
  }
  clearFilter() { this.atencionesAll = [...this.atencionesAll]; }
  verDetalle(_: any) {}
  editarAtencion(_: any) {}
  eliminarAtencion(_: any) {}

  // ==== IMPORT ====
  triggerFilePicker() { (document.getElementById('excelInput') as HTMLInputElement)?.click(); }

  async onFileChange(ev: Event) {
    const input = ev.target as HTMLInputElement;
    if (!input.files || input.files.length === 0) return;
    const file = input.files[0];
    input.value = '';

    try {
      const rows = await this.readExcel(file);
      if (!rows.length) {
        this.messageService.add({ severity:'warn', summary:'Sin filas', detail:'El archivo no contiene datos válidos.' });
        return;
      }
      await this.doImport(rows);
      this.cargarAtenciones();
    } catch (e: any) {
      this.messageService.add({ severity:'error', summary:'Error leyendo Excel', detail: String(e?.message || e) });
    }
  }

  private async readExcel(file: File): Promise<AtencionRow[]> {
    const buf = await file.arrayBuffer();
    const wb = XLSX.read(buf, { type: 'array' });
    const sheet = wb.Sheets[wb.SheetNames[0]];
    const json: any[] = XLSX.utils.sheet_to_json(sheet, { defval: null, raw: false });

    const norm = (s: any) => String(s || '').trim().toLowerCase();
    const mapKey = (k: string): keyof AtencionRow | null => {
      const n = norm(k);
      if (['idclienteerp','id_cliente_erp','clienteerp'].includes(n)) return 'idClienteErp';
      if (['cedula','documento','dni'].includes(n)) return 'cedula';
      if (['nombres','nombre'].includes(n)) return 'nombres';
      if (['apellidos','apellido'].includes(n)) return 'apellidos';
      if (['email','correo'].includes(n)) return 'email';
      if (['telefono','teléfono'].includes(n)) return 'telefono';
      if (['celular','movil','móvil'].includes(n)) return 'celular';
      if (['idagencia','agencia_id','agencia'].includes(n)) return 'idAgencia';
      if (['fechaatencion','fecha_atencion','fecha'].includes(n)) return 'fechaAtencion';
      if (['numerodocumento','numero_documento','doc_numero','# documento','#documento'].includes(n)) return 'numeroDocumento';
      if (['tipodocumento','tipo_documento','doc_tipo','tipo documento','tipo documento'].includes(n)) return 'tipoDocumento';
      if (['numerofactura','numero_factura','factura'].includes(n)) return 'numeroFactura';
      if (['idcanal','canal_id','canal'].includes(n)) return 'idCanal';
      if (['detalle','observacion','observación'].includes(n)) return 'detalle';
      if (['cedulaasesor','asesor_cedula','asesor'].includes(n)) return 'cedulaAsesor';
      return null;
    };

    const out: AtencionRow[] = [];

    for (const r of json) {
      const row: any = {};
      Object.keys(r).forEach(k => {
        const dest = mapKey(k);
        if (dest) row[dest] = r[k];
      });

      // Fecha a YYYY-MM-DD si viene como dd/mm/yyyy o dd-mm-yyyy
      if (row.fechaAtencion) {
        const m = /^(\d{1,2})[\/\-](\d{1,2})[\/\-](\d{2,4})$/.exec(String(row.fechaAtencion));
        if (m) {
          const d = m[1].padStart(2,'0');
          const mo = m[2].padStart(2,'0');
          const y = m[3].length === 2 ? '20'+m[3] : m[3];
          row.fechaAtencion = `${y}-${mo}-${d}`;
        }
      }

      // Normalizaciones numéricas
      if (row.idAgencia != null && row.idAgencia !== '') row.idAgencia = Number(row.idAgencia) || null;
      if (row.idCanal   != null && row.idCanal   !== '') row.idCanal   = Number(row.idCanal)   || null;

      // Mantén la fila (aunque falte algo); validaremos antes de enviar
      out.push(row as AtencionRow);
    }
    return out;
  }

  private filaInvalida(r: AtencionRow): string[] {
    const faltan: string[] = [];
    if (!r.cedula)           faltan.push('cedula');
    if (!r.nombres)          faltan.push('nombres');
    if (!r.apellidos)        faltan.push('apellidos');
    if (!r.idAgencia && r.idAgencia !== 0) faltan.push('idAgencia');
    if (!r.fechaAtencion)    faltan.push('fechaAtencion');
    if (!r.numeroDocumento)  faltan.push('numeroDocumento');
    if (!r.tipoDocumento)    faltan.push('tipoDocumento');
    return faltan;
  }

  private async doImport(rows: AtencionRow[]) {
    this.importing = true;
    this.progress = 0; this.okCount = 0; this.errCount = 0;

    const total = rows.length;

    for (let i = 0; i < total; i++) {
      const r = rows[i];

      // Validación previa para evitar 400 del backend
      const faltan = this.filaInvalida(r);
      if (faltan.length) {
        this.errCount++;
        this.messageService.add({
          severity:'error',
          summary: 'Error en fila',
          detail: `${r.cedula || '(sin cédula)'}: faltan campos [${faltan.join(', ')}]`,
          life: 4500
        });
        this.progress = Math.round(((i+1) / total) * 100);
        continue;
      }

      try {
        // Llamada al upsert
        const res: any = await firstValueFrom(this.atencionesService.upsert(r));
        if (res?.success) {
          this.okCount++;
          this.messageService.add({
            severity:'success',
            summary: 'Importado',
            detail: `${r.cedula} - ${r.nombres} ${r.apellidos}`,
            life: 2200
          });
        } else {
          this.errCount++;
          const msg = res?.message || res?.error || 'Error desconocido';
          this.messageService.add({
            severity:'error',
            summary: 'Error en fila',
            detail: `${r.cedula || '(sin cédula)'}: ${msg}`,
            life: 4500
          });
        }
      } catch (e: any) {
        this.errCount++;
        const msg = e?.error?.message || e?.message || String(e);
        this.messageService.add({
          severity:'error',
          summary: 'Error en fila',
          detail: `${r.cedula || '(sin cédula)'}: ${msg}`,
          life: 4500
        });
      }

      this.progress = Math.round(((i+1) / total) * 100);
      await new Promise(res => setTimeout(res, 15));
    }

    this.importing = false;
    this.messageService.add({
      severity: this.errCount ? 'warn' : 'success',
      summary: 'Importación finalizada',
      detail: `OK: ${this.okCount} · Errores: ${this.errCount}`,
      life: 4500
    });
  }
}
