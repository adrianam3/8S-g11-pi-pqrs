export interface IRol {
  idRol: number;
  nombre: string;
  descripcion: string;
  estado: string;
  fechaCreacion: string;
  fechaActualizacion: string;
}
