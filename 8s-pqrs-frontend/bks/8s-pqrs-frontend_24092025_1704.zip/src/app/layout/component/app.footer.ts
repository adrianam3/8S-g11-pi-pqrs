import { Component } from '@angular/core';

@Component({
    standalone: true,
    selector: 'app-footer',
    template: `<div class="layout-footer">
       IMBAUTO S.A.
    </div>`
})
export class AppFooter {}
