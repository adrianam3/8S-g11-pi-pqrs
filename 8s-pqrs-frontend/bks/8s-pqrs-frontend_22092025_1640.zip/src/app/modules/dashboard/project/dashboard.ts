// import { CommonModule } from '@angular/common';
// import { Component } from '@angular/core';
// import { FormsModule } from '@angular/forms';
// import { RouterModule } from '@angular/router';
// import { ButtonModule } from 'primeng/button';
// import { ConfirmDialog } from 'primeng/confirmdialog';
// import { DialogModule } from 'primeng/dialog';
// import { IconFieldModule } from 'primeng/iconfield';
// import { InputIconModule } from 'primeng/inputicon';
// import { InputTextModule } from 'primeng/inputtext';
// import { ProgressSpinnerModule } from 'primeng/progressspinner';
// import { RippleModule } from 'primeng/ripple';
// import { TableModule } from 'primeng/table';
// import { ToastModule } from 'primeng/toast';



// @Component({
//   selector: 'app-dashboard',
//    imports: [
//         CommonModule,
//         FormsModule,
//         RouterModule,
//         ButtonModule,
//         ToastModule,
//         DialogModule,
//         ProgressSpinnerModule,
//         TableModule,
//         ConfirmDialog,
//         IconFieldModule,
//         InputIconModule,
//         InputTextModule,
//     ],
//   templateUrl: './dashboard.html',
//   styleUrl: './dashboard.scss'
// })
// export class Dashboard {

// }


// import { Component, OnInit } from '@angular/core';
// import { ApiService } from 'src/app/service/api.service';

// @Component({
//   selector: 'app-dashboard',
//   templateUrl: './dashboard.html',
//   styleUrls: ['./dashboard.scss']
// })
// export class DashboardComponent implements OnInit {

//   // Igual que en tus otros componentes:
//   private dashboardApi = `/controllers/dashboard.controller.php?op=`;

//   rango: Date[] | null = null;
//   loading = false;

//   kpis = { csat: 0, nps: 0, ces: 0 };

//   pqrsEstadoData: any = { labels: [], datasets: [{ data: [], label: 'PQRs' }] };
//   encuestasEstadoData: any = { labels: [], datasets: [{ data: [], label: 'Encuestas' }] };

//   constructor(private apiService: ApiService) {}

//   ngOnInit(): void { this.cargar(); }

//   cargar(): void {
//     this.loading = true;
//     const { ini, fin } = this.rangoFechas();

//     // KPIs
//     this.apiService.get(`${this.dashboardApi}kpis&fechaInicio=${ini}&fechaFin=${fin}`)
//       .subscribe({
//         next: (res: any) => this.kpis = res || { csat: 0, nps: 0, ces: 0 },
//         error: () => {},
//       });

//     // PQRs por estado
//     this.apiService.get(`${this.dashboardApi}pqrs_estado&fechaInicio=${ini}&fechaFin=${fin}`)
//       .subscribe({
//         next: (rows: any[]) => {
//           const labels = rows.map(r => r.estado);
//           const data   = rows.map(r => Number(r.total) || 0);
//           this.pqrsEstadoData = { labels, datasets: [{ data, label: 'PQRs' }] };
//         },
//         error: () => {},
//       });

//     // Encuestas por estado
//     this.apiService.get(`${this.dashboardApi}encuestas_estado&fechaInicio=${ini}&fechaFin=${fin}`)
//       .subscribe({
//         next: (rows: any[]) => {
//           const labels = rows.map(r => r.estado);
//           const data   = rows.map(r => Number(r.total) || 0);
//           this.encuestasEstadoData = { labels, datasets: [{ data, label: 'Encuestas' }] };
//         },
//         error: () => {},
//         complete: () => this.loading = false
//       });
//   }

//   private rangoFechas(): { ini: string, fin: string } {
//     if (!this.rango || this.rango.length < 2 || !this.rango[0] || !this.rango[1]) {
//       const hoy = new Date();
//       const ini = new Date(hoy.getFullYear(), hoy.getMonth(), 1);
//       return { ini: this.fmt(ini), fin: this.fmt(hoy) };
//     }
//     return { ini: this.fmt(this.rango[0]), fin: this.fmt(this.rango[1]) };
//     }

//   private fmt(d: Date): string { return d.toISOString().slice(0, 10); }
// }

// // ---funciona

// import { Component, OnInit } from '@angular/core';
// import { CommonModule } from '@angular/common';
// import { FormsModule } from '@angular/forms';

// // PrimeNG
// import { CardModule } from 'primeng/card';
// import { ChartModule } from 'primeng/chart';

// import { ButtonModule } from 'primeng/button';
// import { ProgressSpinnerModule } from 'primeng/progressspinner';
// import { ToastModule } from 'primeng/toast';
// import { DashboardService } from '@/modules/Services/dashboard-service';
// import { ToolbarModule } from 'primeng/toolbar';
// import { ProgressBarModule } from 'primeng/progressbar';
// import { TableModule } from 'primeng/table';
// import { DatePicker } from 'primeng/datepicker';
// import { Select } from 'primeng/select';


// type DateRange = [Date | null, Date | null];

// @Component({
//   selector: 'app-dashboard',
//   standalone: true,
//   imports: [
//      CommonModule,
//     FormsModule,

//     // PrimeNG que usas en el HTML mostrado
//     Select,
//     DatePicker,
//     ToolbarModule,
//     ButtonModule,

//     // Otros que usa el dashboard
//     CardModule,
//     ChartModule,
//     TableModule,
//     ProgressBarModule,
    
//   ],
//   templateUrl: './dashboard.html',
//   styleUrls: ['./dashboard.scss']
// })
// export class Dashboard implements OnInit {
//   // filtros
//   range: DateRange = [this.firstDayOfMonth(), new Date()];
//   periodos = [
//     { label: 'Mensual', value: 'M' },
//     { label: 'Semanal', value: 'W' },
//     { label: 'Trimestral', value: 'Q' },
//     { label: 'Anual', value: 'Y' }
//   ];
//   period = 'M';
//   segmentos = [
//     { label: 'Por canal', value: 'canal' },
//     { label: 'Por agencia', value: 'agencia' }
//   ];
//   segment = 'canal';

//   // datos
//   kpis: any;
//   overview: any;
//   tasaResp: any;
//   encRes: any;
//   pqrsRes: any;
//   conversion: any;

//   // charts
//   lineData: any; lineOptions: any;
//   csatSegBar: any; npsSegBar: any; cesSegBar: any; segBarOptions: any;
//   donutData: any; donutOptions: any;
//   pqrsEstadoData: any;

//   // tablas
//   pqrsCat: any[] = [];
//   pqrsCatPadre: any[] = [];

//   loading = false;

//   constructor(private svc: DashboardService) { }

//   ngOnInit(): void {
//     this.buildChartOptions();
//     this.fetchAll();
//   }

//   // Helpers fechas
//   firstDayOfMonth(): Date {
//     const d = new Date(); return new Date(d.getFullYear(), d.getMonth(), 1);
//   }
//   toYMD(d: Date): string {
//     const p = (n: number) => String(n).padStart(2, '0');
//     return `${d.getFullYear()}-${p(d.getMonth() + 1)}-${p(d.getDate())}`;
//   }
//   get paramsBase() {
//     const [d1, d2] = this.range;
//     return {
//       fechaInicio: this.toYMD(d1 ?? this.firstDayOfMonth()),
//       fechaFin: this.toYMD(d2 ?? new Date())
//     };
//   }

//   refresh() { this.fetchAll(); }
//   onPeriodoChange() { this.refresh(); }
//   onSegmentChange() { this.refresh(); }

//   private fetchAll(): void {
//     this.loading = true;
//     const base = this.paramsBase;

//     // KPIs & overview
//     this.svc.kpis(base).subscribe(r => this.kpis = r);
//     this.svc.cardsOverview(base).subscribe(r => this.overview = r);

//     // Resúmenes y tasas
//     this.svc.tasaRespuesta(base).subscribe(r => this.tasaResp = r);
//     this.svc.encuestasResumen(base).subscribe(r => this.encRes = r);
//     this.svc.pqrsResumen(base).subscribe(r => this.pqrsRes = r);
//     this.svc.encuestasConversion(base).subscribe(r => this.conversion = r);

//     // Tendencia (línea + barras)
//     this.svc.tendenciaSatisfaccionPqrs(base).subscribe((rows: any) => {
//       const labels = rows.map((x: any) => x.periodo);
//       const sat = rows.map((x: any) => x.satisfaccion_5);
//       const pqrs = rows.map((x: any) => x.pqrs);
//       this.lineData = {
//         labels,
//         datasets: [
//           { type: 'line', label: 'Satisfacción (1–5)', data: sat, tension: 0.35, fill: false },
//           { type: 'bar', label: 'PQRs', data: pqrs, yAxisID: 'y1' }
//         ]
//       };
//     });

//     // Segmentos
//     const segParams = { ...base, segment: this.segment };
//     this.svc.csatSegment(segParams).subscribe((rows: any) => {
//       this.csatSegBar = {
//         labels: rows.map((x: any) => x.segmento),
//         datasets: [{ label: 'CSAT (%)', data: rows.map((x: any) => x.csat) }]
//       };
//     });
//     this.svc.npsSegment(segParams).subscribe((rows: any) => {
//       this.npsSegBar = {
//         labels: rows.map((x: any) => x.segmento),
//         datasets: [{ label: 'NPS', data: rows.map((x: any) => x.nps) }]
//       };
//     });
//     this.svc.cesSegment(segParams).subscribe((rows: any) => {
//       this.cesSegBar = {
//         labels: rows.map((x: any) => x.segmento),
//         datasets: [{ label: 'CES (1–5)', data: rows.map((x: any) => x.ces) }]
//       };
//     });

//     // Donut 1..5
//     this.svc.distribucionCalificaciones(base).subscribe((r: any) => {
//       this.donutData = {
//         labels: ['1', '2', '3', '4', '5'],
//         datasets: [{ data: [r.cal_1_pct || 0, r.cal_2_pct || 0, r.cal_3_pct || 0, r.cal_4_pct || 0, r.cal_5_pct || 0] }]
//       };
//     });

//     // PQRs por estado
//     this.svc.pqrsEstado(base).subscribe((rows: any) => {
//       this.pqrsEstadoData = {
//         labels: rows.map((x: any) => x.estado),
//         datasets: [{ label: 'PQRs', data: rows.map((x: any) => x.total) }]
//       };
//     });

//     // tablas
//     this.svc.pqrsPorCategoria(base).subscribe((rows: any) => this.pqrsCat = rows);
//     this.svc.pqrsPorCategoriaPadre(base).subscribe((rows: any) => {
//       this.pqrsCatPadre = rows;
//       this.loading = false;
//     });
//   }

//   private buildChartOptions() {
//     this.lineOptions = {
//       responsive: true,
//       interaction: { mode: 'index', intersect: false },
//       stacked: false,
//       scales: {
//         y: { type: 'linear', position: 'left', min: 0, max: 5, title: { display: true, text: 'Satisfacción (1–5)' } },
//         y1: { type: 'linear', position: 'right', grid: { drawOnChartArea: false }, title: { display: true, text: 'PQRs' } }
//       },
//       plugins: { legend: { position: 'top' } }
//     };
//     this.segBarOptions = {
//       responsive: true,
//       indexAxis: 'y',
//       plugins: { legend: { display: false } },
//       scales: { x: { beginAtZero: true } }
//     };
//     this.donutOptions = { responsive: true, cutout: '60%', plugins: { legend: { position: 'bottom' } } };
//   }
// }

import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';

/** PrimeNG Modules (Angular 20 + PrimeNG 20) */
import { ToolbarModule } from 'primeng/toolbar';
import { DatePickerModule } from 'primeng/datepicker';
import { SelectModule } from 'primeng/select';
import { ButtonModule } from 'primeng/button';
import { CardModule } from 'primeng/card';
import { ChartModule } from 'primeng/chart';
import { TableModule } from 'primeng/table';
import { ProgressBarModule } from 'primeng/progressbar';
import { PanelModule } from 'primeng/panel';
import { DividerModule } from 'primeng/divider';

/** Forms */
import { FormsModule } from '@angular/forms';

/** Service + tipos */
//import { DashboardService, OverviewResponse } from './dashboard-service';

import { DashboardService, OverviewResponse } from '@/modules/Services/dashboard-service';


interface Kpis {
  csat?: number;
  nps?: number;
  ces?: number;
  nps_breakdown?: { promotores_pct?: number; pasivos_pct?: number; detractores_pct?: number };
}

interface Overview {
  satisfaccion_avg_10?: { value: number; delta_abs_vs_prev: number | null };
  total_pqrs?: { value: number; delta_pct_vs_prev: number };
  pqrs_abiertas?: { value: number; delta_pct_vs_prev: number };
  encuestas_enviadas?: { value: number; delta_pct_vs_prev: number };
}

interface SegDatum { label: string; value: number; }
interface PqrsEstado { estado: string; total: number; }

@Component({
  standalone: true,
  selector: 'app-dashboard',
  imports: [
    CommonModule, FormsModule,
    ToolbarModule, DatePickerModule, SelectModule, ButtonModule,
    CardModule, ChartModule, TableModule, ProgressBarModule, PanelModule, DividerModule
  ],
  templateUrl: './dashboard.html',
  styleUrls: ['./dashboard.scss']
})
export class Dashboard implements OnInit {

  /** ======= FILTROS ======= */
  startDate: Date | null = null;
  endDate: Date | null = null;

  periodos = [
    { label: 'Diario', value: 'D' },
    { label: 'Semanal', value: 'W' },
    { label: 'Mensual', value: 'M' },
    { label: 'Trimestral', value: 'Q' }
  ];
  period: 'D'|'W'|'M'|'Q' = 'M';

  segmentos = [
    { label: 'Por canal', value: 'canal' },
    { label: 'Por agencia', value: 'agencia' },
    { label: 'Por categoría', value: 'categoria' }
  ];
  segment: string = 'canal';

  /** ======= KPIs / OVERVIEW ======= */
  kpis: Kpis | null = null;
  overview: Overview | null = null;

  /** ======= CHART DATA ======= */
  lineData: any = null;
  lineOptions: any = null;

  donutData: any = null;
  donutOptions: any = null;

  csatSegBar: any = null;
  npsSegBar: any = null;
  cesSegBar: any = null;
  segBarOptions: any = null;

  pqrsEstadoData: any = null;

  /** ======= TABLAS ======= */
  pqrsCat: Array<{ categoria: string; total: number }> = [];
  pqrsCatPadre: Array<{ categoria_padre: string; total: number }> = [];

  constructor(private dashboardService: DashboardService) {}

  ngOnInit(): void {
    const now = new Date();
    this.startDate = new Date(now.getFullYear(), now.getMonth(), 1);
    this.endDate = new Date(now.getFullYear(), now.getMonth() + 1, 0);
    this.refresh();
  }

  onPeriodoChange() { this.refresh(); }
  onSegmentChange() { this.refresh(); }

  refresh() {
    const inicio = this.startDate ? this.toYmd(this.startDate) : null;
    const fin    = this.endDate   ? this.toYmd(this.endDate)   : null;
    const range  = (inicio && fin) ? [inicio, fin] : null;

    this.dashboardService
      .getOverview({ range, period: this.period, segment: this.segment })
      .subscribe((res: OverviewResponse) => this.applyResponse(res));
  }

  private applyResponse(res: OverviewResponse) {
    this.kpis = res.kpis;
    this.overview = res.overview;

    this.lineData = this.mapLineData(res.tendencia);
    this.lineOptions = this.makeLineOptions();

    this.donutData = this.mapDonutData(res.distribucion15);
    this.donutOptions = this.makeDonutOptions();

    this.csatSegBar = this.mapSegBar(res.csatPorSegmento, '%');
    this.npsSegBar  = this.mapSegBar(res.npsPorSegmento, 'nps');
    this.cesSegBar  = this.mapSegBar(res.cesPorSegmento, '1-5');
    this.segBarOptions = this.makeSegBarOptions('%');

    this.pqrsEstadoData = this.mapPqrsEstado(res.pqrsPorEstado);

    this.pqrsCat = res.pqrsPorCategoria || [];
    this.pqrsCatPadre = res.pqrsPorCategoriaPadre || [];
  }

  private toYmd(d: Date): string {
    const pad = (n: number) => n.toString().padStart(2, '0');
    return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`;
  }

  // ======= MAPEOS CHARTS =======
  mapLineData(src: { labels: string[]; sat15: number[]; pqrs: number[] }) {
    if (!src || !src.labels?.length) return null;
    return {
      labels: src.labels,
      datasets: [
        {
          type: 'line',
          label: 'Satisfacción (1–5)',
          data: src.sat15 ?? [],
          tension: 0.3,
          borderWidth: 2,
          pointRadius: 3,
          yAxisID: 'ySat'
        },
        {
          type: 'bar',
          label: 'PQRs',
          data: src.pqrs ?? [],
          borderWidth: 1,
          yAxisID: 'yPqrs',
          backgroundColor: (ctx: any) => ctx.chart?.options?.color ?? undefined
        }
      ]
    };
  }

  makeLineOptions() {
    return {
      responsive: true,
      maintainAspectRatio: false,
      interaction: { mode: 'index', intersect: false },
      plugins: {
        legend: { position: 'top' },
        tooltip: {
          callbacks: {
            label: (ctx: any) => {
              const v = ctx.parsed.y;
              return ctx.dataset.label === 'Satisfacción (1–5)' ? ` ${v?.toFixed?.(2)}` : ` ${v}`;
            }
          }
        }
      },
      scales: {
        ySat: {
          type: 'linear',
          position: 'left',
          min: 0, max: 5,
          title: { display: true, text: 'Satisfacción (1–5)' }
        },
        yPqrs: {
          type: 'linear',
          position: 'right',
          grid: { drawOnChartArea: false },
          beginAtZero: true,
          title: { display: true, text: 'PQRs' }
        },
        x: { ticks: { autoSkip: true, maxRotation: 0 } }
      }
    };
  }

  mapDonutData(src: { counts?: number[] } | { [k: string]: number }) {
    let data: number[] = [];
    if ((src as any)?.counts) {
      data = (src as any).counts ?? [];
    } else {
      data = [1, 2, 3, 4, 5].map(k => (src as any)?.[k] ?? 0);
    }
    const labels = ['1', '2', '3', '4', '5'];
    return {
      labels,
      datasets: [{ data, borderWidth: 1 }]
    };
  }

  makeDonutOptions() {
    return {
      responsive: true,
      plugins: {
        legend: { position: 'top' },
        tooltip: {
          callbacks: {
            label: (ctx: any) => {
              const total = ctx.dataset.data.reduce((a: number, b: number) => a + b, 0) || 1;
              const val = ctx.parsed;
              const pct = (val * 100) / total;
              return ` ${val} (${pct.toFixed(1)}%)`;
            }
          }
        }
      },
      cutout: '60%'
    };
  }

  mapSegBar(src: SegDatum[], mode: '%' | 'nps' | '1-5' = '%') {
    if (!src?.length) return null;
    return {
      labels: src.map(d => d.label),
      datasets: [
        {
          label: mode === '%' ? 'Porcentaje' : (mode === 'nps' ? 'NPS' : 'Satisfacción'),
          data: src.map(d => d.value),
          borderWidth: 1
        }
      ]
    };
  }

  makeSegBarOptions(mode: '%' | 'nps' | '1-5' = '%') {
    const maxByMode = mode === '%' ? 100 : (mode === 'nps' ? 100 : 5);
    const minByMode = mode === 'nps' ? -100 : 0;
    return {
      indexAxis: 'y' as const,
      responsive: true,
      scales: {
        x: {
          min: minByMode,
          max: maxByMode,
          grid: { color: 'rgba(0,0,0,.05)' },
          ticks: { callback: (v: number) => mode === '%' ? `${v}%` : `${v}` }
        },
        y: { ticks: { autoSkip: false } }
      },
      plugins: {
        legend: { display: false },
        tooltip: {
          callbacks: { label: (ctx: any) => {
            const v = ctx.parsed.x;
            return mode === '%' ? ` ${v}%` : ` ${v}`;
          } }
        }
      }
    };
  }

  mapPqrsEstado(src: PqrsEstado[]) {
    if (!src?.length) return null;
    return {
      labels: src.map(x => x.estado),
      datasets: [{ label: 'PQRs', data: src.map(x => x.total), borderWidth: 1 }]
    };
  }
}
