import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';

import { ToolbarModule } from 'primeng/toolbar';
import { DatePickerModule } from 'primeng/datepicker';
import { SelectModule } from 'primeng/select';
import { ButtonModule } from 'primeng/button';
import { CardModule } from 'primeng/card';
import { ChartModule } from 'primeng/chart';
import { TableModule } from 'primeng/table';
import { ProgressBarModule } from 'primeng/progressbar';
import { PanelModule } from 'primeng/panel';
import { DividerModule } from 'primeng/divider';
import { FormsModule } from '@angular/forms';
import { TabsModule } from 'primeng/tabs';  
import Chart from 'chart.js/auto';
import ChartDataLabels from 'chartjs-plugin-datalabels';
Chart.register(ChartDataLabels);


import { DashboardService, OverviewResponse } from '@/modules/Services/dashboard-service';

interface Kpis {
  csat?: number;
  nps?: number;
  ces?: number;
  nps_breakdown?: { promotores_pct?: number; pasivos_pct?: number; detractores_pct?: number };
}
interface Overview {
  satisfaccion_avg_10?: { value: number; delta_abs_vs_prev: number | null };
  total_pqrs?: { value: number; delta_pct_vs_prev: number };
  pqrs_abiertas?: { value: number; delta_pct_vs_prev: number };
  encuestas_enviadas?: { value: number; delta_pct_vs_prev: number };
}

@Component({
  standalone: true,
  selector: 'app-dashboard',
  imports: [
    CommonModule, FormsModule,
    ToolbarModule, DatePickerModule, SelectModule, ButtonModule,
    CardModule, ChartModule, TableModule, ProgressBarModule, PanelModule, DividerModule, TabsModule,
  ],
  templateUrl: './dashboard.html',
  styleUrls: ['./dashboard.scss']
})
export class Dashboard implements OnInit {
  activeTab: 'encuestas' | 'satisfaccion' | 'pqrs' = 'encuestas'; 
  /** Filtros */
  startDate: Date | null = null;
  endDate: Date | null = null;
  periodos = [
    { label: 'Diario', value: 'D' },
    { label: 'Semanal', value: 'W' },
    { label: 'Mensual', value: 'M' },
    { label: 'Trimestral', value: 'Q' }
  ];
  period: 'D' | 'W' | 'M' | 'Q' = 'M';
  segmentos = [
    { label: 'Por canal', value: 'canal' },
    { label: 'Por agencia', value: 'agencia' },
    { label: 'Por categoría', value: 'categoria' }
  ];
  segment: string = 'canal';

  /** Datos */
  kpis: Kpis | null = null;
  overview: Overview | null = null;

  /** Charts */
  lineData: any = null;
  lineOptions: any = null;

  donutData: any = null;
  donutOptions: any = null;

  csatSegBar: any = null;
  npsSegBar: any = null;
  cesSegBar: any = null;
  csatBarOptions: any = null;
  npsBarOptions: any = null;
  cesBarOptions: any = null;

  pqrsEstadoData: any = null;

  /** Tablas */
  pqrsCat: Array<{ categoria: string; total: number }> = [];
  pqrsCatPadre: Array<{ categoria_padre: string; total: number }> = [];

  constructor(private dashboardService: DashboardService) { }

  ngOnInit(): void {
    const now = new Date();
    this.startDate = new Date(now.getFullYear(), now.getMonth(), 1);
    this.endDate = new Date(now.getFullYear(), now.getMonth() + 1, 0);
    this.refresh();
  }

  onPeriodoChange() { this.refresh(); }
  onSegmentChange() { this.refresh(); }

  refresh() {
    const inicio = this.startDate ? this.toYmd(this.startDate) : null;
    const fin = this.endDate ? this.toYmd(this.endDate) : null;
    const range: [string, string] | null = (inicio && fin) ? [inicio, fin] : null;

    // this.dashboardService
    //   .getOverview({ range, period: this.period, segment: this.segment })
    //   .subscribe((res: OverviewResponse) => this.applyResponse(res));
    this.dashboardService
      .getOverview({ range, period: this.period, segment: this.segment })
      .subscribe((res: OverviewResponse) => {
        console.log('[Dashboard] overview raw:', res);
        console.log('[Dashboard] tendencia raw:', res?.tendencia);
        this.applyResponse(res);
      });



  }

  private applyResponse(res: OverviewResponse) {

    console.log('[Dashboard] tendencia raw:', res?.tendencia);

    this.kpis = res.kpis;
    this.overview = res.overview;

    this.lineData = this.mapLineData(res.tendencia);
    this.lineOptions = this.makeLineOptions();

    this.donutData = this.mapDonutData(res.distribucion15);
    this.donutOptions = this.makeDonutOptions();

    // === OPCIONES INDEPENDIENTES POR CHART ===
    this.csatSegBar = this.mapSegBar(res.csatPorSegmento, { valueKeyGuess: ['csat', 'porcentaje', 'value', 'avg'], labelKeyGuess: ['label', 'canal', 'segmento', 'categoria', 'nombre'] });
    this.npsSegBar = this.mapSegBar(res.npsPorSegmento, { valueKeyGuess: ['nps', 'value', 'puntaje'], labelKeyGuess: ['label', 'canal', 'segmento', 'categoria', 'nombre'] });
    this.cesSegBar = this.mapSegBar(res.cesPorSegmento, { valueKeyGuess: ['ces', 'promedio', 'value', 'avg'], labelKeyGuess: ['label', 'canal', 'segmento', 'categoria', 'nombre'] });

    this.csatBarOptions = this.makeSegBarOptions('%');
    this.npsBarOptions = this.makeSegBarOptions('nps');
    this.cesBarOptions = this.makeSegBarOptions('1-5');

    this.pqrsEstadoData = this.mapPqrsEstado(res.pqrsPorEstado);

    this.pqrsCat = res.pqrsPorCategoria || [];
    this.pqrsCatPadre = res.pqrsPorCategoriaPadre || [];
  }

  // ¿La dona tiene algún valor > 0?
  hasDonutData(): boolean {
    const data = this.donutData?.datasets?.[0]?.data as unknown as any[] | undefined;
    return Array.isArray(data) && data.some(v => Number(v) > 0);
  }


  private toYmd(d: Date): string {
    const pad = (n: number) => n.toString().padStart(2, '0');
    return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`;
  }

  // ======= MAPEOS CHARTS ROBUSTOS =======

  // /** Línea (tendencia) */
  // mapLineData(src: { labels?: string[]; sat15?: number[]; pqrs?: number[] } | any) {
  //   if (!src) return null;
  //   const labels = src.labels ?? src.meses ?? [];
  //   const sat    = src.sat15 ?? src.satisfaccion ?? [];
  //   const pqrs   = src.pqrs ?? src.tickets ?? [];
  //   if (!labels.length) return null;

  //   return {
  //     labels,
  //     datasets: [
  //       { type: 'line', label: 'Satisfacción (1–5)', data: sat, tension: 0.3, borderWidth: 2, pointRadius: 3, yAxisID: 'ySat' },
  //       { type: 'bar',  label: 'PQRs', data: pqrs, borderWidth: 1, yAxisID: 'yPqrs' }
  //     ]
  //   };
  // }

  /** Normaliza arrays a la longitud de labels */
  private normTo<T>(arr: any[] | undefined, len: number, filler: T): T[] {
    const a = (Array.isArray(arr) ? arr : []).map(v => Number(v));
    if (a.length >= len) return a.slice(0, len) as T[];
    return a.concat(Array(len - a.length).fill(filler)) as T[];
  }

  /** Línea (tendencia) – soporta array de puntos {periodo,satisfaccion_5,pqrs} o arrays paralelos */
mapLineData(src: any) {
  if (!src) return null;

  // Caso 1: array de puntos
  if (Array.isArray(src) && src.length && typeof src[0] === 'object') {
    const labels = src.map((p: any) => String(p?.periodo ?? p?.period ?? p?.fecha ?? p?.date ?? ''));
    const sat    = src.map((p: any) => Number(p?.satisfaccion_5 ?? p?.sat15 ?? p?.satisfaccion ?? p?.avg ?? 0));
    const pqrs   = src.map((p: any) => Number(p?.pqrs ?? p?.tickets ?? p?.total ?? p?.cantidad ?? 0));

    if (!labels.length) return null;

    return {
      labels,
      datasets: [
        { type: 'line', label: 'Satisfacción (1–5)', data: sat, tension: 0.3, borderWidth: 2, pointRadius: 3, yAxisID: 'ySat' },
        { type: 'bar',  label: 'PQRs',               data: pqrs, borderWidth: 1, yAxisID: 'yPqrs' }
      ]
    };
  }

  // Caso 2: objeto con arrays paralelos (labels/sat15/pqrs o variantes)
  const labelKeys = ['labels', 'meses', 'periodos', 'fechas', 'dates'];
  const satKeys   = ['sat15', 'satisfaccion', 'satisfaccion_5', 'avg', 'promedio'];
  const pqrsKeys  = ['pqrs', 'tickets', 'total', 'totales', 'counts', 'cantidad', 'casos'];

  const firstKey = (obj: any, keys: string[]) => keys.find(k => Array.isArray(obj?.[k])) ?? null;

  const lblKey = firstKey(src, labelKeys);
  const satKey = firstKey(src, satKeys);
  const pqrKey = firstKey(src, pqrsKeys);

  const labels = (lblKey ? src[lblKey] : []).map((v: any) => String(v));
  if (!labels.length) return null;

  const norm = (arr: any[], n: number) => {
    const a = (Array.isArray(arr) ? arr : []).map((v) => Number(v));
    return a.length >= n ? a.slice(0, n) : a.concat(Array(n - a.length).fill(0));
  };

  const sat  = norm(satKey ? src[satKey] : [], labels.length);
  const pqrs = norm(pqrKey ? src[pqrKey] : [], labels.length);

  return {
    labels,
    datasets: [
      { type: 'line', label: 'Satisfacción (1–5)', data: sat, tension: 0.3, borderWidth: 2, pointRadius: 3, yAxisID: 'ySat' },
      { type: 'bar',  label: 'PQRs',               data: pqrs, borderWidth: 1, yAxisID: 'yPqrs' }
    ]
  };
}




  // makeLineOptions() {
  //   return {
  //     responsive: true, maintainAspectRatio: false,
  //     interaction: { mode: 'index', intersect: false },
  //     plugins: {
  //       legend: { position: 'top' },
  //       tooltip: { callbacks: { label: (ctx: any) => ctx.dataset.label === 'Satisfacción (1–5)' ? ` ${ctx.parsed.y?.toFixed?.(2)}` : ` ${ctx.parsed.y}` } }
  //     },
  //     scales: {
  //       ySat: { type: 'linear', position: 'left', min: 0, max: 5, title: { display: true, text: 'Satisfacción (1–5)' } },
  //       yPqrs:{ type: 'linear', position: 'right', grid: { drawOnChartArea: false }, beginAtZero: true, title: { display: true, text: 'PQRs' } },
  //       x: { ticks: { autoSkip: true, maxRotation: 0 } }
  //     }
  //   };
  // }

  makeLineOptions() {
    return {
      responsive: true,
      maintainAspectRatio: false,
      interaction: { mode: 'index', intersect: false },
      plugins: {
        legend: { position: 'top' },
        tooltip: {
          callbacks: {
            label: (ctx: any) => {
              const v = Number(ctx.parsed.y ?? 0);
              return ctx.dataset?.yAxisID === 'ySat' ? ` ${v.toFixed(2)}` : ` ${v}`;
            }
          }
        }
      },
      scales: {
        ySat: { type: 'linear', position: 'left', min: 0, max: 5, title: { display: true, text: 'Satisfacción (1–5)' } },
        yPqrs: { type: 'linear', position: 'right', grid: { drawOnChartArea: false }, beginAtZero: true, title: { display: true, text: 'PQRs' } },
        x: { ticks: { autoSkip: true, maxRotation: 0 } }
      }
    };
  }


  /** Dona (distribución 1–5) – acepta varios formatos */
  // mapDonutData(src: any) {
  //   if (!src) return null;

  //   // Formatos soportados:
  //   // 1) {counts:[c1..c5]}
  //   // 2) {labels:['1','2',...], values:[...]}
  //   // 3) { '1':c1, '2':c2, ... }  o  { uno: c1, dos: c2, ... }
  //   let labels: string[] = ['1','2','3','4','5'];
  //   let data: number[] = [];

  //   if (Array.isArray(src.counts)) {
  //     data = src.counts;
  //   } else if (Array.isArray(src.labels) && Array.isArray(src.values)) {
  //     labels = src.labels;
  //     data = src.values;
  //   } else {
  //     const keys = ['1','2','3','4','5'];
  //     const alt  = ['uno','dos','tres','cuatro','cinco'];
  //     if (keys.every(k => k in src)) data = keys.map(k => Number(src[k] ?? 0));
  //     else data = alt.map(k => Number(src[k] ?? 0));
  //   }

  //   const total = data.reduce((a,b)=>a+b,0);
  //   if (!total) return { labels, datasets: [{ data: [0,0,0,0,0] }] };

  //   return { labels, datasets: [{ data, borderWidth: 1 }] };
  // }
  /** Dona (distribución 1–5) – acepta muchos formatos */
  mapDonutData(src: any) {
    if (!src) return null;

    // Resultado final
    let labels: string[] = ['1', '2', '3', '4', '5'];
    let data: number[] = [];

    // 1) Array plano
    //    a) [n1,n2,n3,n4,n5]
    //    b) [{label:'1', value:10}, {label:'2', value:5}, ...]
    if (Array.isArray(src)) {
      if (src.length && typeof src[0] === 'number') {
        data = (src as number[]).map(n => Number(n) || 0);
      } else {
        labels = src.map((it: any) => String(it?.label ?? it?.calificacion ?? it?.nombre ?? it?.id ?? it?.key ?? it?.grado ?? it?.score ?? ''));
        data = src.map((it: any) => Number(it?.value ?? it?.values ?? it?.count ?? it?.cantidad ?? it?.total ?? 0) || 0);
      }
    }
    // 2) Objeto tipo {counts:[...]}, o {labels:[...], values:[...]}
    else if (Array.isArray(src.counts)) {
      data = src.counts.map((n: any) => Number(n) || 0);
    } else if (Array.isArray(src.values)) {
      labels = Array.isArray(src.labels) ? src.labels.map((s: any) => String(s)) : labels;
      data = src.values.map((n: any) => Number(n) || 0);
    }
    // 3) Objeto con claves: '1'..'5', o 'uno'..'cinco', o 'calif_1'..'calif_5'
    else {
      const direct = ['1', '2', '3', '4', '5'];
      const words = ['uno', 'dos', 'tres', 'cuatro', 'cinco'];

      if (direct.every(k => k in src)) {
        data = direct.map(k => Number(src[k]) || 0);
        labels = direct;
      } else if (words.every(k => k in src)) {
        data = words.map(k => Number(src[k]) || 0);
        labels = ['1', '2', '3', '4', '5'];
      } else {
        // Busca cualquier clave que incluya un dígito 1..5 (ej. calif_1)
        const buckets = new Array(5).fill(0);
        Object.keys(src).forEach(k => {
          const m = /(\d)/.exec(k);
          if (m) {
            const idx = parseInt(m[1], 10) - 1;
            if (idx >= 0 && idx < 5) buckets[idx] = Number((src as any)[k]) || 0;
          }
        });
        data = buckets;
      }
    }

    // Sanea NaN -> 0
    data = data.map(n => (Number.isFinite(n) ? n : 0));

    // Devuelve estructura válida (aunque total sea 0 para no romper)
    return {
      labels,
      datasets: [{ data, borderWidth: 1 }]
    };
  }


makeDonutOptions() {
  return {
    responsive: true,
    maintainAspectRatio: false,          // <— importante: respetar .chart-box
    layout: {                            // <— acolchado interno para que no toque bordes
      padding: { top: 8, right: 8, bottom: 8, left: 8 }
    },
    plugins: {
      legend: { position: 'top' },
      datalabels: {
        formatter: (value: number, ctx: any) => {
          const data = (ctx.chart.data.datasets?.[0]?.data ?? []) as number[];
          const total = data.reduce((a: number, b: number) => a + (Number(b) || 0), 0) || 1;
          const pct = (Number(value) * 100) / total;
          return pct >= 1 ? `${pct.toFixed(0)}%` : '';
        },
        anchor: 'center',
        align: 'center',
        clamp: true,                      // <— no se dibuja fuera del chart area
        clip: true,                       // <— recorta si se pasa
        font: (ctx: any) => {
          const w = ctx.chart?.width || 300;
          const base = Math.max(10, Math.min(14, Math.floor(w / 25)));
          return { size: base, weight: '600' };
        }
      },
      tooltip: {
        callbacks: {
          label: (ctx: any) => {
            const data = ctx.dataset.data as number[];
            const total = data.reduce((a: number, b: number) => a + (Number(b) || 0), 0) || 1;
            const val = Number(ctx.parsed);
            const pct = (val * 100) / total;
            return ` ${val} (${pct.toFixed(1)}%)`;
          }
        }
      }
    },
    cutout: '62%'                         // <— un poco más de hueco interior ayuda
  };
}



  /** Barras por segmento – autodetecta claves de etiqueta/valor */
  mapSegBar(src: any[], opts: { labelKeyGuess: string[]; valueKeyGuess: string[] }) {
    if (!Array.isArray(src) || !src.length) return null;

    const getFirstKey = (obj: any, keys: string[]) => keys.find(k => obj && (k in obj))!;
    const labels: string[] = [];
    const values: number[] = [];

    for (const row of src) {
      const lk = getFirstKey(row, opts.labelKeyGuess) ?? Object.keys(row)[0];
      const vk = getFirstKey(row, opts.valueKeyGuess) ?? Object.keys(row)[1];

      labels.push(String(row[lk]));
      values.push(Number(row[vk]));
    }

    return { labels, datasets: [{ label: '', data: values, borderWidth: 1 }] };
  }

  /** Opciones para barras horizontales: %, NPS, 1–5 (independientes por chart) */
  makeSegBarOptions(mode: '%' | 'nps' | '1-5' = '%') {
    const maxByMode = mode === '%' ? 100 : (mode === 'nps' ? 100 : 5);
    const minByMode = mode === 'nps' ? -100 : 0;
    return {
      indexAxis: 'y' as const,
      responsive: true,
      maintainAspectRatio: false,
      scales: {
        x: {
          min: minByMode, max: maxByMode,
          grid: { color: 'rgba(0,0,0,.05)' },
          ticks: { callback: (v: number) => mode === '%' ? `${v}%` : `${v}` }
        },
        y: { ticks: { autoSkip: false } }
      },
      plugins: {
        legend: { display: false },
        tooltip: {
          callbacks: {
            label: (ctx: any) => {
              const v = ctx.parsed.x;
              return mode === '%' ? ` ${v}%` : ` ${v}`;
            }
          }
        }
      }
    };
  }

  mapPqrsEstado(src: any[]) {
    if (!Array.isArray(src) || !src.length) return null;
    const labels = src.map((x: any) => String(x?.estado ?? x?.status ?? ''));
    const data = src.map((x: any) => Number(x?.total ?? x?.cantidad ?? 0));
    return { labels, datasets: [{ label: 'PQRs', data, borderWidth: 1 }] };
  }

}
