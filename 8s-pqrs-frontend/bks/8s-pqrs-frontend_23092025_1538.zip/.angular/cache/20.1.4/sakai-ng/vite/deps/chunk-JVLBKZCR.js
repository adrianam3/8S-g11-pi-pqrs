import {
  Chart,
  registerables
} from "./chunk-KA4K4MYT.js";

// node_modules/chart.js/auto/auto.js
Chart.register(...registerables);
var auto_default = Chart;

export {
  auto_default
};
//# sourceMappingURL=chunk-JVLBKZCR.js.map
